configure({
  sources: [
    source('amd', 'tinymce/inlite', '../../src/main/js', mapper.hierarchical)
  ]
});
